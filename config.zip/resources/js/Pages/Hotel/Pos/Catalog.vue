<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, useForm } from '@inertiajs/vue3';

defineProps({ outlets: Array });
const outlet = useForm({ name: '', code: '', is_active: true });
const category = useForm({ pos_outlet_id: '', name: '', sort_order: 0, is_active: true });
const product = useForm({ pos_category_id: '', name: '', sku: '', price: 0, is_active: true });
const money = (n) => Number(n || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' });
</script>

<template>
    <Head title="Catálogo POS" />
    <AuthenticatedLayout>
        <template #header>Catálogo POS</template>
        <div class="row g-3 mb-3">
            <form class="col-md-4 card card-body" @submit.prevent="outlet.post(route('pos.outlets.store'), { onSuccess: () => outlet.reset() })">
                <h6>Nuevo punto de venta</h6>
                <input v-model="outlet.name" class="form-control mb-2" placeholder="Nombre" required />
                <input v-model="outlet.code" class="form-control mb-2" placeholder="código" required />
                <button class="btn btn-primary">Crear</button>
            </form>
            <form class="col-md-4 card card-body" @submit.prevent="category.post(route('pos.categories.store'), { onSuccess: () => category.reset() })">
                <h6>Nueva categoría</h6>
                <select v-model="category.pos_outlet_id" class="form-select mb-2" required>
                    <option value="">Punto de venta</option>
                    <option v-for="item in outlets" :key="item.id" :value="item.id">{{ item.name }}</option>
                </select>
                <input v-model="category.name" class="form-control mb-2" placeholder="Nombre" required />
                <button class="btn btn-primary">Crear</button>
            </form>
            <form class="col-md-4 card card-body" @submit.prevent="product.post(route('pos.products.store'), { onSuccess: () => product.reset() })">
                <h6>Nuevo producto</h6>
                <select v-model="product.pos_category_id" class="form-select mb-2" required>
                    <option value="">Categoría</option>
                    <template v-for="item in outlets" :key="item.id">
                        <option v-for="cat in item.categories" :key="cat.id" :value="cat.id">{{ item.name }} · {{ cat.name }}</option>
                    </template>
                </select>
                <input v-model="product.name" class="form-control mb-2" placeholder="Nombre" required />
                <input v-model="product.price" type="number" step="0.01" min="0" class="form-control mb-2" required />
                <button class="btn btn-primary">Crear</button>
            </form>
        </div>
        <div v-for="item in outlets" :key="item.id" class="card mb-3">
            <div class="card-header">{{ item.name }} <small class="text-muted">{{ item.code }}</small></div>
            <div class="card-body">
                <div v-for="cat in item.categories" :key="cat.id" class="mb-2">
                    <strong>{{ cat.name }}</strong>
                    <ul class="mb-0">
                        <li v-for="prod in cat.products" :key="prod.id">{{ prod.name }} — {{ money(prod.price) }}</li>
                    </ul>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
