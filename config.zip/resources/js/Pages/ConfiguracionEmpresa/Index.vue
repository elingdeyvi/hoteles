<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, useForm } from '@inertiajs/vue3';

const props = defineProps({ config: Object });
const form = useForm({
    nombre_empresa: props.config?.nombre_empresa || '',
    nombre_corto: props.config?.nombre_corto || '',
    nombre_largo: props.config?.nombre_largo || '',
    rfc: props.config?.rfc || '',
    telefono: props.config?.telefono || '',
    email: props.config?.email || '',
    direccion: props.config?.direccion || '',
    ciudad: props.config?.ciudad || '',
    estado: props.config?.estado || '',
    color_primario: props.config?.color_primario || '#1a365d',
    color_secundario: props.config?.color_secundario || '#64748b',
    logo: null,
});
const submit = () => form.post(route('configuracion-empresa.update'), { forceFormData: true, method: 'put' });
</script>

<template>
    <Head title="Empresa" />
    <AuthenticatedLayout>
        <template #header>Configuración de empresa</template>
        <form class="card card-body" @submit.prevent="submit">
            <div class="row g-3">
                <div class="col-md-6"><label class="form-label">Nombre</label><input v-model="form.nombre_empresa" class="form-control" required /></div>
                <div class="col-md-3"><label class="form-label">Nombre corto</label><input v-model="form.nombre_corto" class="form-control" /></div>
                <div class="col-md-3"><label class="form-label">RFC</label><input v-model="form.rfc" class="form-control" /></div>
                <div class="col-md-6"><label class="form-label">Nombre largo</label><input v-model="form.nombre_largo" class="form-control" /></div>
                <div class="col-md-3"><label class="form-label">Teléfono</label><input v-model="form.telefono" class="form-control" /></div>
                <div class="col-md-3"><label class="form-label">Correo</label><input v-model="form.email" type="email" class="form-control" /></div>
                <div class="col-12"><label class="form-label">Dirección</label><textarea v-model="form.direccion" class="form-control" rows="2"></textarea></div>
                <div class="col-md-3"><label class="form-label">Color primario</label><input v-model="form.color_primario" type="color" class="form-control form-control-color" /></div>
                <div class="col-md-3"><label class="form-label">Color secundario</label><input v-model="form.color_secundario" type="color" class="form-control form-control-color" /></div>
                <div class="col-md-6"><label class="form-label">Logo</label><input type="file" class="form-control" accept="image/*" @input="form.logo = $event.target.files[0]" /></div>
                <div class="col-12" v-if="config?.logo_url"><img :src="config.logo_url" alt="" height="48" /></div>
            </div>
            <button class="btn btn-primary mt-3">Guardar</button>
        </form>
    </AuthenticatedLayout>
</template>
