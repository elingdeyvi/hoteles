<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title inertia><?php echo e(config('app.name', 'POS negocios')); ?></title>

        <link rel="icon" href="/favicon.ico?v=2" sizes="any">
        <link rel="icon" type="image/png" href="<?php echo e(asset('favicon-32x32.png')); ?>?v=2" sizes="32x32">
        <link rel="icon" type="image/png" href="<?php echo e(asset('favicon-16x16.png')); ?>?v=2" sizes="16x16">
        <link rel="apple-touch-icon" href="<?php echo e(asset('apple-touch-icon.png')); ?>?v=2">
        <link rel="shortcut icon" href="/favicon.ico?v=2">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=source-sans-3:300,400,500,600,700&display=swap" rel="stylesheet" />

        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', "resources/js/Pages/{$page['component']}.vue"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH C:\proyecto_personal\personales\POSNegocio-v2\resources\views/app.blade.php ENDPATH**/ ?>