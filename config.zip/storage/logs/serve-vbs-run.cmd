@echo off
cd /d "C:\proyecto_personal\personales\POSNegocio-v2"
"C:\xampp4\php\php.exe" artisan serve --host=127.0.0.1 --port=8085 >> "C:\proyecto_personal\personales\POSNegocio-v2\storage\logs\serve-vbs.log" 2>&1
